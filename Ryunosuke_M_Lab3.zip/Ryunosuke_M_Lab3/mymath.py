import math

def SolveAxPlusB(a, b):
    if a == 0:
        return "a should be other than 0."
    else:
        x = ((-b) / a)
        x = "x = " + str(x)
    return x

def SolveHypotenuse(a, b):
    c = math.sqrt((a * a) + (b * b))
    c = str(c)
    return c