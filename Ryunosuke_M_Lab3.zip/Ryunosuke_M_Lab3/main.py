import mymath

a = 0
b = 0

a = input('Please enter your number A: ')
b = input('Please enter your number B: ')



a = float(a)
b = float(b)

print(mymath.SolveAxPlusB(a, b))

result = mymath.SolveHypotenuse(a, b)

print("C = " + result)